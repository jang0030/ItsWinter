package mobilesdkdemo.rbbn.itswinter.recipe;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import mobilesdkdemo.rbbn.itswinter.R;

public class activity_recipe_page extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_recipe_page);
    }
}