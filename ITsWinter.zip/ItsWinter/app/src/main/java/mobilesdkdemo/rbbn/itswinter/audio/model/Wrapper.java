package mobilesdkdemo.rbbn.itswinter.audio.model;

import java.util.List;

public class Wrapper {
    List<Album> album;
    List<Track> track;
}

